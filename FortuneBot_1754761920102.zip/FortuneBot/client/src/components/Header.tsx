import { Link, useLocation } from "wouter";
import { Crown, Wallet, History, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Header() {
  const [location] = useLocation();
  
  // Mock Telegram user data - in real app this would come from Telegram Web App
  const mockTelegramUser = {
    id: "demo123",
    first_name: "Демо",
    username: "demo_user"
  };

  const { data: player } = useQuery({
    queryKey: ["/api/player", mockTelegramUser.id],
    queryFn: async () => {
      const response = await fetch(`/api/player/${mockTelegramUser.id}`);
      if (response.status === 404) {
        // Create new player if not exists
        const createResponse = await fetch("/api/player", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            telegramId: mockTelegramUser.id,
            username: mockTelegramUser.username,
            firstName: mockTelegramUser.first_name,
          }),
        });
        return createResponse.json();
      }
      return response.json();
    },
  });

  const navItems = [
    { path: "/", label: "Главная", icon: Home },
    { path: "/wallet", label: "Кошелек", icon: Wallet },
    { path: "/history", label: "История", icon: History },
  ];

  return (
    <header className="bg-casino-header border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-golden-gradient rounded-full flex items-center justify-center">
              <Crown className="w-5 h-5 text-black" />
            </div>
            <span className="text-xl font-bold text-golden">Golden Palace</span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    size="sm"
                    className={isActive ? "bg-golden-gradient text-black" : "text-golden-light hover:text-golden"}
                    data-testid={`nav-${item.label.toLowerCase()}`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </nav>

          {/* User Info & Balance */}
          <div className="flex items-center space-x-4">
            {player && (
              <>
                <div className="text-right">
                  <div className="text-sm text-golden-light">
                    {player.firstName || player.username || "Игрок"}
                  </div>
                  <div className="text-lg font-bold text-golden" data-testid="user-balance">
                    ${player.balance?.toLocaleString() || "0"}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Mobile Navigation */}
        <nav className="md:hidden flex items-center justify-around py-2 border-t border-border">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            return (
              <Link key={item.path} href={item.path}>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`flex flex-col items-center p-2 ${
                    isActive ? "text-golden" : "text-golden-light"
                  }`}
                  data-testid={`mobile-nav-${item.label.toLowerCase()}`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-xs mt-1">{item.label}</span>
                </Button>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}