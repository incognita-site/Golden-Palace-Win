import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Copy, ExternalLink, TrendingUp, TrendingDown } from "lucide-react";

const mockTelegramUser = {
  id: "demo123",
  first_name: "Демо",
  username: "demo_user"
};

export default function WalletPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [depositAmount, setDepositAmount] = useState("");
  const [depositCurrency, setDepositCurrency] = useState("USDT");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawCurrency, setWithdrawCurrency] = useState("USDT");
  const [withdrawAddress, setWithdrawAddress] = useState("");

  // Get player data
  const { data: player } = useQuery({
    queryKey: ["/api/player", mockTelegramUser.id],
  });

  // Get crypto transactions
  const { data: transactions } = useQuery({
    queryKey: ["/api/crypto/transactions", player?.id],
    enabled: !!player?.id,
  });

  // Get withdrawal requests
  const { data: withdrawals } = useQuery({
    queryKey: ["/api/crypto/withdrawals", player?.id],
    enabled: !!player?.id,
  });

  // Deposit mutation
  const depositMutation = useMutation({
    mutationFn: async ({ amount, currency }: { amount: number; currency: string }) => {
      const response = await fetch("/api/crypto/deposit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerId: mockTelegramUser.id,
          cryptoCurrency: currency,
          amount: amount,
        }),
      });
      if (!response.ok) throw new Error("Failed to create deposit");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/crypto/transactions"] });
      toast({
        title: "Депозит создан",
        description: "Следуйте инструкциям для пополнения баланса",
      });
      setDepositAmount("");
      // Show send bot instructions
      navigator.clipboard.writeText(data.sendBotInstructions.sendBotCommand);
      toast({
        title: "Команда скопирована!",
        description: "Вставьте команду в чат с @send ботом",
      });
    },
  });

  // Withdraw mutation
  const withdrawMutation = useMutation({
    mutationFn: async ({ amount, currency, address }: { amount: number; currency: string; address: string }) => {
      const response = await fetch("/api/crypto/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerId: mockTelegramUser.id,
          amount: amount,
          cryptoCurrency: currency,
          walletAddress: address,
        }),
      });
      if (!response.ok) throw new Error("Failed to create withdrawal");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/player"] });
      queryClient.invalidateQueries({ queryKey: ["/api/crypto/withdrawals"] });
      toast({
        title: "Заявка на вывод создана",
        description: "Обработка займет до 24 часов",
      });
      setWithdrawAmount("");
      setWithdrawAddress("");
    },
  });

  const cryptoOptions = [
    { value: "USDT", label: "USDT", rate: 1 },
    { value: "BTC", label: "Bitcoin", rate: 45000 },
    { value: "ETH", label: "Ethereum", rate: 2500 },
    { value: "TON", label: "Toncoin", rate: 2.5 },
    { value: "TRX", label: "TRON", rate: 0.08 },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-500";
      case "pending": return "bg-yellow-500";
      case "failed": case "rejected": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <Card className="bg-casino-card">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-golden">Ваш баланс</CardTitle>
          <CardDescription className="text-3xl font-bold text-golden">
            ${player?.balance?.toLocaleString() || "0"}
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="deposit" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-casino-card">
          <TabsTrigger value="deposit" className="data-[state=active]:bg-golden data-[state=active]:text-black">
            Пополнить
          </TabsTrigger>
          <TabsTrigger value="withdraw" className="data-[state=active]:bg-golden data-[state=active]:text-black">
            Вывести
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-golden data-[state=active]:text-black">
            История
          </TabsTrigger>
        </TabsList>

        {/* Deposit Tab */}
        <TabsContent value="deposit">
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden">Пополнить баланс</CardTitle>
              <CardDescription>
                Используйте @send бота для быстрого пополнения криптовалютой
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="deposit-amount">Сумма в USD</Label>
                <Input
                  id="deposit-amount"
                  type="number"
                  placeholder="100"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="bg-input border-border"
                  data-testid="input-deposit-amount"
                />
              </div>
              
              <div>
                <Label htmlFor="deposit-currency">Криптовалюта</Label>
                <Select value={depositCurrency} onValueChange={setDepositCurrency}>
                  <SelectTrigger className="bg-input border-border" data-testid="select-deposit-currency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {cryptoOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label} ({option.value})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {depositAmount && (
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">К получению:</div>
                  <div className="text-lg font-semibold text-golden">
                    {(parseFloat(depositAmount) / (cryptoOptions.find(c => c.value === depositCurrency)?.rate || 1)).toFixed(8)} {depositCurrency}
                  </div>
                </div>
              )}

              <Button
                onClick={() => {
                  if (!depositAmount || parseFloat(depositAmount) < 1) return;
                  depositMutation.mutate({
                    amount: parseFloat(depositAmount),
                    currency: depositCurrency,
                  });
                }}
                disabled={!depositAmount || parseFloat(depositAmount) < 1 || depositMutation.isPending}
                className="w-full bg-golden-gradient text-black hover:opacity-90"
                data-testid="button-create-deposit"
              >
                {depositMutation.isPending ? "Создание..." : "Создать депозит"}
              </Button>

              <div className="p-4 bg-muted rounded-lg text-sm">
                <div className="font-semibold text-golden mb-2">Как пополнить:</div>
                <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                  <li>Нажмите "Создать депозит"</li>
                  <li>Команда для @send бота скопируется автоматически</li>
                  <li>Вставьте команду в чат с @send ботом</li>
                  <li>Подтвердите перевод</li>
                  <li>Баланс обновится автоматически</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Withdraw Tab */}
        <TabsContent value="withdraw">
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden">Вывести средства</CardTitle>
              <CardDescription>
                Минимальная сумма вывода: $10
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="withdraw-amount">Сумма в USD</Label>
                <Input
                  id="withdraw-amount"
                  type="number"
                  placeholder="10"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="bg-input border-border"
                  data-testid="input-withdraw-amount"
                />
              </div>
              
              <div>
                <Label htmlFor="withdraw-currency">Криптовалюта</Label>
                <Select value={withdrawCurrency} onValueChange={setWithdrawCurrency}>
                  <SelectTrigger className="bg-input border-border" data-testid="select-withdraw-currency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {cryptoOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label} ({option.value})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="withdraw-address">Адрес кошелька</Label>
                <Input
                  id="withdraw-address"
                  placeholder="Введите адрес вашего кошелька"
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  className="bg-input border-border"
                  data-testid="input-withdraw-address"
                />
              </div>

              <Button
                onClick={() => {
                  if (!withdrawAmount || !withdrawAddress || parseFloat(withdrawAmount) < 10) return;
                  withdrawMutation.mutate({
                    amount: parseFloat(withdrawAmount),
                    currency: withdrawCurrency,
                    address: withdrawAddress,
                  });
                }}
                disabled={
                  !withdrawAmount || 
                  !withdrawAddress || 
                  parseFloat(withdrawAmount) < 10 || 
                  withdrawMutation.isPending ||
                  (player?.balance || 0) < parseFloat(withdrawAmount || "0")
                }
                className="w-full bg-golden-gradient text-black hover:opacity-90"
                data-testid="button-create-withdrawal"
              >
                {withdrawMutation.isPending ? "Создание..." : "Создать заявку"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history">
          <div className="space-y-4">
            {/* Recent Transactions */}
            <Card className="bg-casino-card">
              <CardHeader>
                <CardTitle className="text-golden">Депозиты и переводы</CardTitle>
              </CardHeader>
              <CardContent>
                {transactions?.length ? (
                  <div className="space-y-3">
                    {transactions.map((transaction: any) => (
                      <div key={transaction.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center space-x-3">
                          {transaction.transactionType === "deposit" ? (
                            <TrendingUp className="w-5 h-5 text-green-500" />
                          ) : (
                            <TrendingDown className="w-5 h-5 text-red-500" />
                          )}
                          <div>
                            <div className="font-medium">
                              {transaction.transactionType === "deposit" ? "Пополнение" : "Вывод"} {transaction.cryptoCurrency}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {new Date(transaction.createdAt).toLocaleDateString("ru-RU")}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">${transaction.amount}</div>
                          <Badge className={getStatusColor(transaction.status)}>
                            {transaction.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    История транзакций пуста
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Withdrawal Requests */}
            <Card className="bg-casino-card">
              <CardHeader>
                <CardTitle className="text-golden">Заявки на вывод</CardTitle>
              </CardHeader>
              <CardContent>
                {withdrawals?.length ? (
                  <div className="space-y-3">
                    {withdrawals.map((withdrawal: any) => (
                      <div key={withdrawal.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <div className="font-medium">Вывод {withdrawal.cryptoCurrency}</div>
                          <div className="text-sm text-muted-foreground">
                            {new Date(withdrawal.createdAt).toLocaleDateString("ru-RU")}
                          </div>
                          <div className="text-xs text-muted-foreground truncate max-w-[200px]">
                            {withdrawal.walletAddress}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">${withdrawal.amount}</div>
                          <Badge className={getStatusColor(withdrawal.status)}>
                            {withdrawal.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    Заявок на вывод нет
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}