import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Coins, Play, RotateCcw } from "lucide-react";

const mockTelegramUser = {
  id: "demo123",
  first_name: "Демо",
  username: "demo_user"
};

export default function SlotsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [betAmount, setBetAmount] = useState("10");
  const [reels, setReels] = useState(["🍒", "🍒", "🍒"]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [lastWin, setLastWin] = useState<number | null>(null);

  const { data: player } = useQuery({
    queryKey: ["/api/player", mockTelegramUser.id],
  });

  const spinMutation = useMutation({
    mutationFn: async (betAmount: number) => {
      const response = await fetch(`/api/slots/${mockTelegramUser.id}/spin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ betAmount }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to spin");
      }
      return response.json();
    },
    onMutate: () => {
      setIsSpinning(true);
      setLastWin(null);
    },
    onSuccess: (data) => {
      // Simulate spinning animation
      const animationSteps = 15;
      let step = 0;
      
      const animate = () => {
        if (step < animationSteps) {
          const symbols = ["🍒", "🍋", "🍊", "🔔", "⭐", "💎", "7️⃣"];
          setReels([
            symbols[Math.floor(Math.random() * symbols.length)],
            symbols[Math.floor(Math.random() * symbols.length)],
            symbols[Math.floor(Math.random() * symbols.length)]
          ]);
          step++;
          setTimeout(animate, 100);
        } else {
          setReels(data.reels);
          setLastWin(data.winAmount);
          setIsSpinning(false);
          
          if (data.isWin) {
            toast({
              title: "🎉 Выигрыш!",
              description: `Вы выиграли $${data.winAmount}!`,
            });
          }
          
          queryClient.invalidateQueries({ queryKey: ["/api/player"] });
        }
      };
      
      animate();
    },
    onError: (error: Error) => {
      setIsSpinning(false);
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSpin = () => {
    const bet = parseFloat(betAmount);
    if (!bet || bet < 1) {
      toast({
        title: "Ошибка",
        description: "Минимальная ставка $1",
        variant: "destructive",
      });
      return;
    }
    
    if (!player || player.balance < bet) {
      toast({
        title: "Недостаточно средств",
        description: "Пополните баланс для продолжения игры",
        variant: "destructive",
      });
      return;
    }
    
    spinMutation.mutate(bet);
  };

  const quickBets = [1, 5, 10, 25, 50];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-golden flex items-center justify-center gap-2">
          <Coins className="w-8 h-8" />
          Игровые автоматы
        </h1>
        <p className="text-golden-light">
          Соберите три одинаковых символа для выигрыша!
        </p>
      </div>

      {/* Game Area */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Slot Machine */}
        <div className="lg:col-span-2">
          <Card className="bg-casino-card">
            <CardHeader className="text-center">
              <CardTitle className="text-golden">Golden Slots</CardTitle>
              <CardDescription>
                {player && `Баланс: $${player.balance.toLocaleString()}`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Reels */}
              <div className="bg-black rounded-lg p-8 border-4 border-golden">
                <div className="flex justify-center items-center space-x-4">
                  {reels.map((symbol, index) => (
                    <div
                      key={index}
                      className={`w-20 h-20 bg-casino-card rounded-lg flex items-center justify-center text-4xl border-2 border-golden/50 ${
                        isSpinning ? "animate-spin" : ""
                      }`}
                      data-testid={`reel-${index}`}
                    >
                      {symbol}
                    </div>
                  ))}
                </div>
                
                {/* Win Display */}
                {lastWin !== null && (
                  <div className="text-center mt-4">
                    {lastWin > 0 ? (
                      <div className="text-2xl font-bold text-green-500 animate-pulse">
                        🎉 Выигрыш: ${lastWin}!
                      </div>
                    ) : (
                      <div className="text-lg text-red-500">
                        Попробуйте еще раз
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="bet-amount">Ставка ($)</Label>
                  <Input
                    id="bet-amount"
                    type="number"
                    min="1"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    className="bg-input border-border text-center text-lg"
                    data-testid="input-bet-amount"
                  />
                </div>

                {/* Quick Bet Buttons */}
                <div className="flex flex-wrap gap-2">
                  {quickBets.map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      size="sm"
                      onClick={() => setBetAmount(amount.toString())}
                      className="border-golden/50 text-golden hover:bg-golden hover:text-black"
                      data-testid={`quick-bet-${amount}`}
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>

                {/* Spin Button */}
                <Button
                  onClick={handleSpin}
                  disabled={isSpinning || spinMutation.isPending}
                  className="w-full h-14 text-lg bg-golden-gradient text-black hover:opacity-90 font-bold"
                  data-testid="button-spin"
                >
                  {isSpinning ? (
                    <>
                      <RotateCcw className="w-5 h-5 mr-2 animate-spin" />
                      Крутим...
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      Крутить (${betAmount})
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Info Panel */}
        <div className="space-y-4">
          {/* Paytable */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Таблица выплат</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-2xl">7️⃣ 7️⃣ 7️⃣</span>
                <span className="text-golden font-bold">x10</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-2xl">💎 💎 💎</span>
                <span className="text-golden font-bold">x8</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-2xl">⭐ ⭐ ⭐</span>
                <span className="text-golden font-bold">x6</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-2xl">🔔 🔔 🔔</span>
                <span className="text-golden font-bold">x4</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-2xl">🍒 🍒 🍒</span>
                <span className="text-golden font-bold">x3</span>
              </div>
              <div className="border-t border-border pt-2 mt-2">
                <div className="text-sm text-golden-light">
                  Две одинаковые: x2
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Game Rules */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Правила</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-golden-light">
              <p>• Минимальная ставка: $1</p>
              <p>• Три одинаковых символа = выигрыш</p>
              <p>• Два одинаковых = удвоение ставки</p>
              <p>• Джекпот 7️⃣7️⃣7️⃣ = ставка x10</p>
              <p>• Выигрыш зачисляется мгновенно</p>
            </CardContent>
          </Card>

          {/* Statistics */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Статистика</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-golden-light">RTP:</span>
                <span className="text-golden">95%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-golden-light">Макс. выигрыш:</span>
                <span className="text-golden">$10,000</span>
              </div>
              <div className="flex justify-between">
                <span className="text-golden-light">Шанс джекпота:</span>
                <span className="text-golden">1:343</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}