import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Shuffle3, Play, RotateCcw } from "lucide-react";

const mockTelegramUser = {
  id: "demo123",
  first_name: "Демо",
  username: "demo_user"
};

type Bet = {
  type: string;
  value: number | string;
  amount: number;
  label: string;
};

export default function RoulettePage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [bets, setBets] = useState<Bet[]>([]);
  const [betAmount, setBetAmount] = useState("5");
  const [isSpinning, setIsSpinning] = useState(false);
  const [winningNumber, setWinningNumber] = useState<number | null>(null);
  const [lastResult, setLastResult] = useState<any>(null);

  const { data: player } = useQuery({
    queryKey: ["/api/player", mockTelegramUser.id],
  });

  const spinMutation = useMutation({
    mutationFn: async (bets: Bet[]) => {
      const response = await fetch("/api/roulette/spin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerId: mockTelegramUser.id,
          bets: bets.map(bet => ({
            type: bet.type,
            value: bet.value,
            amount: bet.amount
          }))
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to spin");
      }
      return response.json();
    },
    onMutate: () => {
      setIsSpinning(true);
      setWinningNumber(null);
      setLastResult(null);
    },
    onSuccess: (data) => {
      // Simulate spinning animation
      let spins = 20;
      let currentSpin = 0;
      
      const animate = () => {
        if (currentSpin < spins) {
          setWinningNumber(Math.floor(Math.random() * 37));
          currentSpin++;
          setTimeout(animate, 100);
        } else {
          setWinningNumber(data.winningNumber);
          setLastResult(data);
          setIsSpinning(false);
          setBets([]); // Clear bets after spin
          
          if (data.isWin) {
            toast({
              title: "🎉 Выигрыш!",
              description: `Выпало ${data.winningNumber}! Выигрыш: $${data.totalWin}`,
            });
          } else {
            toast({
              title: `Выпало ${data.winningNumber}`,
              description: "В этот раз не повезло, попробуйте еще!",
            });
          }
          
          queryClient.invalidateQueries({ queryKey: ["/api/player"] });
        }
      };
      
      animate();
    },
    onError: (error: Error) => {
      setIsSpinning(false);
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addBet = (type: string, value: number | string, label: string) => {
    const amount = parseFloat(betAmount);
    if (!amount || amount < 1) {
      toast({
        title: "Ошибка",
        description: "Минимальная ставка $1",
        variant: "destructive",
      });
      return;
    }

    const newBet: Bet = { type, value, amount, label };
    setBets([...bets, newBet]);
  };

  const removeBet = (index: number) => {
    setBets(bets.filter((_, i) => i !== index));
  };

  const clearBets = () => {
    setBets([]);
  };

  const spin = () => {
    if (bets.length === 0) {
      toast({
        title: "Ошибка",
        description: "Сделайте хотя бы одну ставку",
        variant: "destructive",
      });
      return;
    }

    const totalBetAmount = bets.reduce((sum, bet) => sum + bet.amount, 0);
    if (!player || player.balance < totalBetAmount) {
      toast({
        title: "Недостаточно средств",
        description: "Пополните баланс для продолжения игры",
        variant: "destructive",
      });
      return;
    }

    spinMutation.mutate(bets);
  };

  const generateNumbers = () => {
    const numbers = [];
    for (let i = 0; i <= 36; i++) {
      const isRed = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(i);
      numbers.push({
        number: i,
        color: i === 0 ? "green" : isRed ? "red" : "black"
      });
    }
    return numbers;
  };

  const numbers = generateNumbers();
  const totalBetAmount = bets.reduce((sum, bet) => sum + bet.amount, 0);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-golden flex items-center justify-center gap-2">
          <Shuffle3 className="w-8 h-8" />
          Рулетка
        </h1>
        <p className="text-golden-light">
          Поставьте на номер, цвет или четность и выиграйте до x35!
        </p>
      </div>

      {/* Game Area */}
      <div className="grid lg:grid-cols-4 gap-6">
        {/* Roulette Wheel & Table */}
        <div className="lg:col-span-3">
          <Card className="bg-casino-card">
            <CardHeader className="text-center">
              <CardTitle className="text-golden">Европейская рулетка</CardTitle>
              <CardDescription>
                {player && `Баланс: $${player.balance.toLocaleString()}`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Wheel */}
              <div className="text-center">
                <div className={`w-32 h-32 mx-auto rounded-full border-8 border-golden bg-casino-card flex items-center justify-center ${isSpinning ? 'spin-slow' : ''}`}>
                  <div className="text-3xl font-bold text-golden" data-testid="winning-number">
                    {winningNumber !== null ? winningNumber : "?"}
                  </div>
                </div>
                {lastResult && (
                  <div className="mt-4 text-center">
                    <div className="text-lg font-semibold">
                      Последний результат: {lastResult.winningNumber}
                    </div>
                    {lastResult.isWin && (
                      <div className="text-green-500 font-bold">
                        Выигрыш: ${lastResult.totalWin}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Betting Table */}
              <div className="space-y-4">
                {/* Numbers Grid */}
                <div className="bg-muted p-4 rounded-lg">
                  <div className="grid grid-cols-13 gap-1 mb-4">
                    {/* Zero */}
                    <button
                      onClick={() => addBet("number", 0, "0")}
                      disabled={isSpinning}
                      className="col-span-1 h-12 bg-green-600 text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="number-0"
                    >
                      0
                    </button>
                    
                    {/* Numbers 1-36 */}
                    {Array.from({ length: 36 }, (_, i) => i + 1).map((num) => {
                      const isRed = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(num);
                      return (
                        <button
                          key={num}
                          onClick={() => addBet("number", num, num.toString())}
                          disabled={isSpinning}
                          className={`h-12 font-bold rounded hover:opacity-80 disabled:opacity-50 ${
                            isRed ? "bg-red-600 text-white" : "bg-black text-white"
                          }`}
                          data-testid={`number-${num}`}
                        >
                          {num}
                        </button>
                      );
                    })}
                  </div>

                  {/* Outside Bets */}
                  <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-sm">
                    <button
                      onClick={() => addBet("red", "red", "Красное")}
                      disabled={isSpinning}
                      className="h-10 bg-red-600 text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="bet-red"
                    >
                      Красное (x2)
                    </button>
                    <button
                      onClick={() => addBet("black", "black", "Чёрное")}
                      disabled={isSpinning}
                      className="h-10 bg-black text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="bet-black"
                    >
                      Чёрное (x2)
                    </button>
                    <button
                      onClick={() => addBet("even", "even", "Чётное")}
                      disabled={isSpinning}
                      className="h-10 bg-gray-600 text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="bet-even"
                    >
                      Чётное (x2)
                    </button>
                    <button
                      onClick={() => addBet("odd", "odd", "Нечётное")}
                      disabled={isSpinning}
                      className="h-10 bg-gray-600 text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="bet-odd"
                    >
                      Нечётное (x2)
                    </button>
                    <button
                      onClick={() => addBet("low", "low", "1-18")}
                      disabled={isSpinning}
                      className="h-10 bg-blue-600 text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="bet-low"
                    >
                      1-18 (x2)
                    </button>
                    <button
                      onClick={() => addBet("high", "high", "19-36")}
                      disabled={isSpinning}
                      className="h-10 bg-blue-600 text-white font-bold rounded hover:opacity-80 disabled:opacity-50"
                      data-testid="bet-high"
                    >
                      19-36 (x2)
                    </button>
                  </div>
                </div>

                {/* Controls */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex-1">
                      <Label htmlFor="bet-amount">Размер ставки ($)</Label>
                      <Input
                        id="bet-amount"
                        type="number"
                        min="1"
                        value={betAmount}
                        onChange={(e) => setBetAmount(e.target.value)}
                        className="bg-input border-border"
                        data-testid="input-bet-amount"
                      />
                    </div>
                    <div className="space-x-2">
                      {[1, 5, 10, 25].map((amount) => (
                        <Button
                          key={amount}
                          variant="outline"
                          size="sm"
                          onClick={() => setBetAmount(amount.toString())}
                          className="border-golden/50 text-golden hover:bg-golden hover:text-black"
                        >
                          ${amount}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-center space-x-4">
                    <Button
                      onClick={clearBets}
                      variant="outline"
                      disabled={isSpinning || bets.length === 0}
                      className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
                      data-testid="button-clear-bets"
                    >
                      Очистить ставки
                    </Button>
                    <Button
                      onClick={spin}
                      disabled={isSpinning || bets.length === 0}
                      className="bg-golden-gradient text-black hover:opacity-90 font-bold min-w-32"
                      data-testid="button-spin"
                    >
                      {isSpinning ? (
                        <>
                          <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                          Крутим...
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Крутить (${totalBetAmount})
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Info Panel */}
        <div className="space-y-4">
          {/* Current Bets */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Ваши ставки</CardTitle>
            </CardHeader>
            <CardContent>
              {bets.length > 0 ? (
                <div className="space-y-2">
                  {bets.map((bet, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                      <span className="text-sm">{bet.label}</span>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">${bet.amount}</Badge>
                        <button
                          onClick={() => removeBet(index)}
                          className="text-red-500 hover:text-red-700 text-xs"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  ))}
                  <div className="border-t pt-2 font-bold text-golden">
                    Всего: ${totalBetAmount}
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-4">
                  Ставок нет
                </div>
              )}
            </CardContent>
          </Card>

          {/* Payouts */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Выплаты</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Номер</span>
                <span className="text-golden font-bold">x35</span>
              </div>
              <div className="flex justify-between">
                <span>Цвет/Четность</span>
                <span className="text-golden font-bold">x2</span>
              </div>
              <div className="flex justify-between">
                <span>1-18 / 19-36</span>
                <span className="text-golden font-bold">x2</span>
              </div>
            </CardContent>
          </Card>

          {/* Rules */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Правила</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-golden-light">
              <p>• Минимальная ставка: $1</p>
              <p>• Максимум 37 номеров (0-36)</p>
              <p>• Ноль не четное и не красное</p>
              <p>• Можно делать много ставок</p>
              <p>• Выплаты мгновенные</p>
            </CardContent>
          </Card>

          {/* Statistics */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Статистика</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-golden-light">RTP:</span>
                <span className="text-golden">97.3%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-golden-light">Макс. выигрыш:</span>
                <span className="text-golden">$35,000</span>
              </div>
              <div className="flex justify-between">
                <span className="text-golden-light">Шанс номера:</span>
                <span className="text-golden">1:37</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}