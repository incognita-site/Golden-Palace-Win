import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { History, TrendingUp, TrendingDown, Coins, Spade, Shuffle3 } from "lucide-react";

const mockTelegramUser = {
  id: "demo123",
  first_name: "Демо",
  username: "demo_user"
};

export default function HistoryPage() {
  const { data: player } = useQuery({
    queryKey: ["/api/player", mockTelegramUser.id],
  });

  const { data: gameHistory } = useQuery({
    queryKey: ["/api/player", player?.id, "history"],
    enabled: !!player?.id,
  });

  const getGameIcon = (gameType: string) => {
    switch (gameType) {
      case "slots": return Coins;
      case "blackjack": return Spade;
      case "roulette": return Shuffle3;
      default: return History;
    }
  };

  const getGameName = (gameType: string) => {
    switch (gameType) {
      case "slots": return "Слоты";
      case "blackjack": return "Блэкджек";
      case "roulette": return "Рулетка";
      default: return gameType;
    }
  };

  const formatGameData = (gameType: string, gameData: string | null) => {
    if (!gameData) return null;
    
    try {
      const data = JSON.parse(gameData);
      
      switch (gameType) {
        case "slots":
          return `Комбинация: ${data.reels?.join(" ") || data.symbols?.join(" ") || "Неизвестно"}`;
        case "blackjack":
          return `Карты игрока: ${data.playerCards?.join(", ") || "Неизвестно"}`;
        case "roulette":
          return `Выпало: ${data.winningNumber ?? "Неизвестно"}`;
        default:
          return null;
      }
    } catch {
      return null;
    }
  };

  // Mock statistics for demo
  const stats = {
    totalGames: gameHistory?.length || 0,
    totalWagered: gameHistory?.reduce((sum: number, game: any) => sum + (game.betAmount || 0), 0) || 0,
    totalWon: gameHistory?.reduce((sum: number, game: any) => sum + (game.winAmount || 0), 0) || 0,
    biggestWin: Math.max(...(gameHistory?.map((game: any) => game.winAmount || 0) || [0])),
    favoriteGame: "slots", // This would be calculated from actual data
  };

  const profit = stats.totalWon - stats.totalWagered;
  const winRate = stats.totalGames > 0 ? ((gameHistory?.filter((game: any) => game.winAmount > 0).length || 0) / stats.totalGames * 100) : 0;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-golden flex items-center justify-center gap-2">
          <History className="w-8 h-8" />
          История игр
        </h1>
        <p className="text-golden-light">
          Просмотрите свою игровую статистику и историю ставок
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-casino-card">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-golden">{stats.totalGames}</div>
            <div className="text-sm text-golden-light">Всего игр</div>
          </CardContent>
        </Card>
        
        <Card className="bg-casino-card">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-golden">${stats.totalWagered.toLocaleString()}</div>
            <div className="text-sm text-golden-light">Поставлено</div>
          </CardContent>
        </Card>
        
        <Card className="bg-casino-card">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-golden">${stats.totalWon.toLocaleString()}</div>
            <div className="text-sm text-golden-light">Выиграно</div>
          </CardContent>
        </Card>
        
        <Card className="bg-casino-card">
          <CardContent className="p-6 text-center">
            <div className={`text-2xl font-bold ${profit >= 0 ? "text-green-500" : "text-red-500"}`}>
              ${Math.abs(profit).toLocaleString()}
            </div>
            <div className="text-sm text-golden-light">
              {profit >= 0 ? "Прибыль" : "Убыток"}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Statistics */}
      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="bg-casino-card">
          <CardHeader>
            <CardTitle className="text-golden">Общая статистика</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-golden-light">Процент побед:</span>
              <span className="text-golden font-bold">{winRate.toFixed(1)}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-golden-light">Средняя ставка:</span>
              <span className="text-golden font-bold">
                ${stats.totalGames > 0 ? (stats.totalWagered / stats.totalGames).toFixed(2) : "0"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-golden-light">Самый крупный выигрыш:</span>
              <span className="text-green-500 font-bold">${stats.biggestWin.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-golden-light">Любимая игра:</span>
              <span className="text-golden font-bold">Слоты</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-casino-card">
          <CardHeader>
            <CardTitle className="text-golden">По играм</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {["slots", "blackjack", "roulette"].map((gameType) => {
              const gameGames = gameHistory?.filter((game: any) => game.gameType === gameType) || [];
              const gameWon = gameGames.reduce((sum: number, game: any) => sum + (game.winAmount || 0), 0);
              const gameWagered = gameGames.reduce((sum: number, game: any) => sum + (game.betAmount || 0), 0);
              const Icon = getGameIcon(gameType);
              
              return (
                <div key={gameType} className="flex items-center justify-between p-2 bg-muted rounded">
                  <div className="flex items-center space-x-2">
                    <Icon className="w-4 h-4 text-golden" />
                    <span className="text-sm">{getGameName(gameType)}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-golden">{gameGames.length} игр</div>
                    <div className={`text-xs ${gameWon - gameWagered >= 0 ? "text-green-500" : "text-red-500"}`}>
                      {gameWon - gameWagered >= 0 ? "+" : ""}${(gameWon - gameWagered).toLocaleString()}
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card className="bg-casino-card">
          <CardHeader>
            <CardTitle className="text-golden">Последние результаты</CardTitle>
          </CardHeader>
          <CardContent>
            {gameHistory?.slice(0, 5).map((game: any, index: number) => {
              const isWin = game.winAmount > 0;
              const Icon = getGameIcon(game.gameType);
              
              return (
                <div key={index} className="flex items-center justify-between p-2 border-b border-border last:border-0">
                  <div className="flex items-center space-x-2">
                    <Icon className="w-4 h-4 text-golden" />
                    <div>
                      <div className="text-sm font-medium">{getGameName(game.gameType)}</div>
                      <div className="text-xs text-muted-foreground">
                        Ставка: ${game.betAmount}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    {isWin ? (
                      <TrendingUp className="w-4 h-4 text-green-500 inline mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500 inline mr-1" />
                    )}
                    <span className={`text-sm font-semibold ${isWin ? "text-green-500" : "text-red-500"}`}>
                      {isWin ? "+" : ""}${isWin ? game.winAmount.toLocaleString() : (game.betAmount * -1).toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            }) || (
              <div className="text-center text-muted-foreground py-4">
                История игр пуста
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Game History Table */}
      <Card className="bg-casino-card">
        <CardHeader>
          <CardTitle className="text-golden">Полная история</CardTitle>
          <CardDescription>
            Детальная информация о всех ваших играх
          </CardDescription>
        </CardHeader>
        <CardContent>
          {gameHistory?.length ? (
            <div className="space-y-2">
              {gameHistory.map((game: any, index: number) => {
                const Icon = getGameIcon(game.gameType);
                const isWin = game.winAmount > 0;
                const profit = game.winAmount - game.betAmount;
                const gameDetails = formatGameData(game.gameType, game.gameData);
                
                return (
                  <div key={index} className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <Icon className="w-5 h-5 text-golden" />
                        <div>
                          <div className="font-medium text-golden">{getGameName(game.gameType)}</div>
                          <div className="text-sm text-muted-foreground">
                            {new Date(game.createdAt).toLocaleString("ru-RU")}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">Ставка: ${game.betAmount}</div>
                        {isWin ? (
                          <Badge className="bg-green-500 hover:bg-green-600">
                            Выигрыш: ${game.winAmount}
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            Проигрыш
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    {gameDetails && (
                      <div className="text-sm text-golden-light mt-2 p-2 bg-background rounded">
                        {gameDetails}
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center mt-2 pt-2 border-t border-border">
                      <span className="text-sm text-muted-foreground">
                        Чистый результат:
                      </span>
                      <span className={`font-bold ${profit >= 0 ? "text-green-500" : "text-red-500"}`}>
                        {profit >= 0 ? "+" : ""}${profit.toLocaleString()}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-12">
              <History className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <div className="text-xl mb-2">История игр пуста</div>
              <div className="text-sm">
                Начните играть, чтобы увидеть здесь свою статистику
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}