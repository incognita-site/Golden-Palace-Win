import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Coins, Spade, Shuffle3 } from "lucide-react";

export default function HomePage() {
  const games = [
    {
      id: "slots",
      title: "Слоты",
      description: "Классические игровые автоматы с джекпотами",
      icon: Coins,
      path: "/slots",
      color: "from-yellow-500 to-orange-600",
    },
    {
      id: "blackjack",
      title: "Блэкджек",
      description: "Карточная игра против дилера. Наберите 21!",
      icon: Spade,
      path: "/blackjack",
      color: "from-red-500 to-pink-600",
    },
    {
      id: "roulette",
      title: "Рулетка",
      description: "Поставьте на номер, цвет или четность",
      icon: Shuffle3,
      path: "/roulette",
      color: "from-green-500 to-emerald-600",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-bold text-golden">
          🏛️ Golden Palace
        </h1>
        <p className="text-xl text-golden-light max-w-2xl mx-auto">
          Добро пожаловать в роскошное онлайн-казино! 
          Играйте в свои любимые игры и выигрывайте крупные призы.
        </p>
        <div className="bg-casino-card rounded-lg p-6 max-w-md mx-auto">
          <div className="text-lg text-golden-light">Ваш баланс</div>
          <div className="text-3xl font-bold text-golden">$1,000</div>
          <div className="text-sm text-muted-foreground mt-2">
            Начальный бонус для новых игроков
          </div>
        </div>
      </div>

      {/* Games Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        {games.map((game) => {
          const Icon = game.icon;
          return (
            <Card 
              key={game.id} 
              className="bg-casino-card hover:scale-105 transition-transform cursor-pointer"
              data-testid={`game-card-${game.id}`}
            >
              <CardHeader className="text-center">
                <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${game.color} flex items-center justify-center mb-4`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-golden text-xl">{game.title}</CardTitle>
                <CardDescription className="text-golden-light">
                  {game.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href={game.path}>
                  <Button 
                    className="w-full bg-golden-gradient text-black hover:opacity-90 font-semibold"
                    data-testid={`play-${game.id}`}
                  >
                    Играть
                  </Button>
                </Link>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Features Section */}
      <div className="bg-casino-card rounded-lg p-8">
        <h2 className="text-2xl font-bold text-golden mb-6 text-center">
          Почему Golden Palace?
        </h2>
        <div className="grid md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl mb-2">💰</div>
            <h3 className="text-lg font-semibold text-golden">Криптоплатежи</h3>
            <p className="text-golden-light text-sm">
              Быстрые депозиты и выводы через @send бота
            </p>
          </div>
          <div>
            <div className="text-3xl mb-2">🔒</div>
            <h3 className="text-lg font-semibold text-golden">Безопасность</h3>
            <p className="text-golden-light text-sm">
              Честные игры с прозрачными алгоритмами
            </p>
          </div>
          <div>
            <div className="text-3xl mb-2">⚡</div>
            <h3 className="text-lg font-semibold text-golden">Мгновенно</h3>
            <p className="text-golden-light text-sm">
              Играйте прямо в Telegram без регистрации
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold text-golden">
          Готовы попытать удачу?
        </h2>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/wallet">
            <Button 
              variant="outline" 
              size="lg"
              className="border-golden text-golden hover:bg-golden hover:text-black"
              data-testid="button-deposit"
            >
              💳 Пополнить баланс
            </Button>
          </Link>
          <Link href="/slots">
            <Button 
              size="lg"
              className="bg-golden-gradient text-black hover:opacity-90 font-semibold"
              data-testid="button-start-playing"
            >
              🎰 Начать играть
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}