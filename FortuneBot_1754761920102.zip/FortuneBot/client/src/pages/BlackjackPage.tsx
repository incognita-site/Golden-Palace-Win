import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Spade, Play, Hand, Square } from "lucide-react";

const mockTelegramUser = {
  id: "demo123",
  first_name: "Демо",
  username: "demo_user"
};

export default function BlackjackPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [betAmount, setBetAmount] = useState("10");
  const [gameState, setGameState] = useState<any>(null);

  const { data: player } = useQuery({
    queryKey: ["/api/player", mockTelegramUser.id],
  });

  const { data: blackjackState } = useQuery({
    queryKey: ["/api/blackjack", player?.id],
    enabled: !!player?.id,
  });

  const startGameMutation = useMutation({
    mutationFn: async (betAmount: number) => {
      const response = await fetch("/api/blackjack/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerId: mockTelegramUser.id,
          betAmount,
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to start game");
      }
      return response.json();
    },
    onSuccess: (data) => {
      setGameState(data);
      queryClient.invalidateQueries({ queryKey: ["/api/blackjack"] });
      queryClient.invalidateQueries({ queryKey: ["/api/player"] });
      
      if (data.gameStatus === "blackjack") {
        toast({
          title: "🃏 Блэкджек!",
          description: `Поздравляем! Выигрыш: $${data.betAmount * 1.5}`,
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mock hit/stand actions for demo
  const hitMutation = useMutation({
    mutationFn: async () => {
      // This would normally call the backend
      // For demo, we'll simulate drawing a card
      const suits = ["♠", "♥", "♦", "♣"];
      const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
      const newCard = ranks[Math.floor(Math.random() * ranks.length)] + suits[Math.floor(Math.random() * suits.length)];
      
      const newPlayerCards = [...gameState.playerCards, newCard];
      const newScore = calculateScore(newPlayerCards);
      
      let newStatus = gameState.gameStatus;
      if (newScore > 21) {
        newStatus = "bust";
        toast({
          title: "💥 Перебор!",
          description: "Вы проиграли",
          variant: "destructive",
        });
      }
      
      return {
        ...gameState,
        playerCards: newPlayerCards,
        playerScore: newScore,
        gameStatus: newStatus,
        isActive: newScore <= 21
      };
    },
    onSuccess: (data) => {
      setGameState(data);
    },
  });

  const standMutation = useMutation({
    mutationFn: async () => {
      // Simulate dealer play
      let dealerCards = [...gameState.dealerCards];
      let dealerScore = calculateScore(dealerCards);
      
      // Dealer draws until 17
      const suits = ["♠", "♥", "♦", "♣"];
      const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
      
      while (dealerScore < 17) {
        const newCard = ranks[Math.floor(Math.random() * ranks.length)] + suits[Math.floor(Math.random() * suits.length)];
        dealerCards.push(newCard);
        dealerScore = calculateScore(dealerCards);
      }
      
      // Determine winner
      let newStatus = "tie";
      let winAmount = 0;
      
      if (dealerScore > 21) {
        newStatus = "player_wins";
        winAmount = gameState.betAmount * 2;
      } else if (gameState.playerScore > dealerScore) {
        newStatus = "player_wins";
        winAmount = gameState.betAmount * 2;
      } else if (dealerScore > gameState.playerScore) {
        newStatus = "dealer_wins";
      } else {
        newStatus = "tie";
        winAmount = gameState.betAmount; // Return bet
      }
      
      return {
        ...gameState,
        dealerCards,
        dealerScore,
        gameStatus: newStatus,
        isActive: false,
        winAmount
      };
    },
    onSuccess: (data) => {
      setGameState(data);
      
      // Update player balance locally for demo
      if (data.winAmount > 0) {
        toast({
          title: data.gameStatus === "player_wins" ? "🎉 Вы выиграли!" : "🤝 Ничья",
          description: `Выигрыш: $${data.winAmount}`,
        });
      } else {
        toast({
          title: "😞 Дилер выиграл",
          description: "Попробуйте еще раз!",
        });
      }
    },
  });

  const calculateScore = (cards: string[]): number => {
    let score = 0;
    let aces = 0;
    
    for (const card of cards) {
      const rank = card.slice(0, -1);
      if (rank === "A") {
        aces++;
        score += 11;
      } else if (["J", "Q", "K"].includes(rank)) {
        score += 10;
      } else {
        score += parseInt(rank);
      }
    }
    
    while (score > 21 && aces > 0) {
      score -= 10;
      aces--;
    }
    
    return score;
  };

  const startNewGame = () => {
    const bet = parseFloat(betAmount);
    if (!bet || bet < 1) {
      toast({
        title: "Ошибка",
        description: "Минимальная ставка $1",
        variant: "destructive",
      });
      return;
    }
    
    if (!player || player.balance < bet) {
      toast({
        title: "Недостаточно средств",
        description: "Пополните баланс для продолжения игры",
        variant: "destructive",
      });
      return;
    }
    
    startGameMutation.mutate(bet);
  };

  const resetGame = () => {
    setGameState(null);
  };

  const quickBets = [1, 5, 10, 25, 50];
  const currentGame = gameState || blackjackState;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-golden flex items-center justify-center gap-2">
          <Spade className="w-8 h-8" />
          Блэкджек
        </h1>
        <p className="text-golden-light">
          Наберите 21 очко или больше дилера, но не перебирайте!
        </p>
      </div>

      {/* Game Area */}
      <div className="grid lg:grid-cols-4 gap-6">
        {/* Game Table */}
        <div className="lg:col-span-3">
          <Card className="bg-casino-card">
            <CardHeader className="text-center">
              <CardTitle className="text-golden">Игровой стол</CardTitle>
              <CardDescription>
                {player && `Баланс: $${player.balance.toLocaleString()}`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {!currentGame ? (
                /* New Game Setup */
                <div className="space-y-6 text-center">
                  <div className="bg-muted rounded-lg p-8">
                    <h3 className="text-xl text-golden mb-4">Начать новую игру</h3>
                    
                    <div className="max-w-sm mx-auto space-y-4">
                      <div>
                        <Label htmlFor="bet-amount">Ставка ($)</Label>
                        <Input
                          id="bet-amount"
                          type="number"
                          min="1"
                          value={betAmount}
                          onChange={(e) => setBetAmount(e.target.value)}
                          className="bg-input border-border text-center text-lg"
                          data-testid="input-bet-amount"
                        />
                      </div>

                      <div className="flex flex-wrap gap-2 justify-center">
                        {quickBets.map((amount) => (
                          <Button
                            key={amount}
                            variant="outline"
                            size="sm"
                            onClick={() => setBetAmount(amount.toString())}
                            className="border-golden/50 text-golden hover:bg-golden hover:text-black"
                            data-testid={`quick-bet-${amount}`}
                          >
                            ${amount}
                          </Button>
                        ))}
                      </div>

                      <Button
                        onClick={startNewGame}
                        disabled={startGameMutation.isPending}
                        className="w-full h-12 text-lg bg-golden-gradient text-black hover:opacity-90 font-bold"
                        data-testid="button-start-game"
                      >
                        <Play className="w-5 h-5 mr-2" />
                        Начать игру (${betAmount})
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Active Game */
                <div className="space-y-6">
                  {/* Dealer's Hand */}
                  <div className="text-center">
                    <h3 className="text-lg font-semibold text-golden mb-3">Дилер</h3>
                    <div className="flex justify-center space-x-2 mb-2">
                      {currentGame.dealerCards.map((card: string, index: number) => (
                        <div
                          key={index}
                          className={`w-16 h-24 bg-white rounded-lg flex items-center justify-center text-black font-bold text-sm border-2 ${
                            (card.includes("♥") || card.includes("♦")) ? "text-red-600" : "text-black"
                          }`}
                          data-testid={`dealer-card-${index}`}
                        >
                          {index === 1 && currentGame.isActive ? "🎴" : card}
                        </div>
                      ))}
                    </div>
                    <div className="text-golden font-semibold" data-testid="dealer-score">
                      Очки: {currentGame.isActive ? "?" : currentGame.dealerScore}
                    </div>
                  </div>

                  {/* Game Status */}
                  <div className="text-center py-4 bg-muted rounded-lg">
                    {currentGame.gameStatus === "active" ? (
                      <div className="text-golden text-lg">Ваш ход</div>
                    ) : (
                      <div className="space-y-2">
                        <div className="text-xl font-bold">
                          {currentGame.gameStatus === "player_wins" && "🎉 Вы выиграли!"}
                          {currentGame.gameStatus === "dealer_wins" && "😞 Дилер выиграл"}
                          {currentGame.gameStatus === "tie" && "🤝 Ничья"}
                          {currentGame.gameStatus === "blackjack" && "🃏 Блэкджек!"}
                          {currentGame.gameStatus === "bust" && "💥 Перебор!"}
                        </div>
                        <div className="text-golden">
                          Ставка: ${currentGame.betAmount}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Player's Hand */}
                  <div className="text-center">
                    <h3 className="text-lg font-semibold text-golden mb-3">Ваши карты</h3>
                    <div className="flex justify-center space-x-2 mb-2">
                      {currentGame.playerCards.map((card: string, index: number) => (
                        <div
                          key={index}
                          className={`w-16 h-24 bg-white rounded-lg flex items-center justify-center font-bold text-sm border-2 ${
                            (card.includes("♥") || card.includes("♦")) ? "text-red-600" : "text-black"
                          }`}
                          data-testid={`player-card-${index}`}
                        >
                          {card}
                        </div>
                      ))}
                    </div>
                    <div className="text-golden font-semibold" data-testid="player-score">
                      Очки: {currentGame.playerScore}
                    </div>
                  </div>

                  {/* Game Controls */}
                  <div className="flex justify-center space-x-4">
                    {currentGame.isActive && currentGame.gameStatus === "active" ? (
                      <>
                        <Button
                          onClick={() => hitMutation.mutate()}
                          disabled={hitMutation.isPending}
                          className="bg-green-600 hover:bg-green-700 text-white"
                          data-testid="button-hit"
                        >
                          <Hand className="w-4 h-4 mr-2" />
                          Взять карту
                        </Button>
                        <Button
                          onClick={() => standMutation.mutate()}
                          disabled={standMutation.isPending}
                          className="bg-red-600 hover:bg-red-700 text-white"
                          data-testid="button-stand"
                        >
                          <Square className="w-4 h-4 mr-2" />
                          Остаться
                        </Button>
                      </>
                    ) : (
                      <Button
                        onClick={resetGame}
                        className="bg-golden-gradient text-black hover:opacity-90 font-bold"
                        data-testid="button-new-game"
                      >
                        Новая игра
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Info Panel */}
        <div className="space-y-4">
          {/* Rules */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Правила</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-golden-light">
              <p>• Цель: набрать 21 очко</p>
              <p>• Туз = 1 или 11 очков</p>
              <p>• Король, Дама, Валет = 10 очков</p>
              <p>• Блэкджек = выигрыш x1.5</p>
              <p>• Дилер берет до 17 очков</p>
              <p>• Перебор = проигрыш</p>
            </CardContent>
          </Card>

          {/* Card Values */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Ценности карт</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>A (Туз)</span>
                <span className="text-golden">1 или 11</span>
              </div>
              <div className="flex justify-between">
                <span>K, Q, J</span>
                <span className="text-golden">10</span>
              </div>
              <div className="flex justify-between">
                <span>2-10</span>
                <span className="text-golden">Номинал</span>
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          <Card className="bg-casino-card">
            <CardHeader>
              <CardTitle className="text-golden text-lg">Статистика</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-golden-light">RTP:</span>
                <span className="text-golden">99.5%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-golden-light">Блэкджек:</span>
                <span className="text-golden">1.5x</span>
              </div>
              <div className="flex justify-between">
                <span className="text-golden-light">Обычный выигрыш:</span>
                <span className="text-golden">2x</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}