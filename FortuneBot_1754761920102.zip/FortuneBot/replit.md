# Golden Palace Casino

## Project Overview
A luxury Telegram Web App casino featuring:
- **Games**: Slots, Blackjack, Roulette
- **Design**: Luxury gold and black theme
- **Payment**: Cryptocurrency integration through @send bot
- **Platform**: Telegram Web App optimized interface

## Project Architecture

### Technology Stack
- **Frontend**: React 18 with TypeScript
- **Backend**: Express.js with TypeScript  
- **State Management**: TanStack Query v5
- **UI Framework**: shadcn/ui with Tailwind CSS
- **Storage**: In-memory storage for development
- **Routing**: Wouter for client-side routing

### Directory Structure
```
├── client/src/
│   ├── components/ui/     # shadcn/ui components
│   ├── pages/            # Main application pages
│   ├── hooks/            # Custom React hooks
│   ├── lib/              # Utilities and configurations
│   └── App.tsx           # Main application component
├── server/
│   ├── index.ts          # Express server setup
│   ├── routes.ts         # API routes
│   └── storage.ts        # In-memory storage interface
└── shared/
    └── schema.ts         # Shared TypeScript types and Zod schemas
```

### Database Schema
Comprehensive data models for:
- **Users**: Authentication and balance management
- **Games**: Session tracking and state persistence  
- **Transactions**: Payment and withdrawal records
- **Crypto Operations**: @send bot integration

### API Endpoints
- **Authentication**: User registration and login
- **Games**: Game state management and results
- **Wallet**: Balance updates and crypto operations
- **History**: Transaction and game history

## User Preferences
- **Language**: Russian interface preferred
- **Theme**: Dark luxury theme with gold accents
- **Integration**: Essential @send Telegram bot integration for deposits

## Recent Changes
- **2025-01-08**: Complete project structure established
- **UI Components**: All shadcn/ui components implemented
- **Styling**: Luxury casino theme with dark/gold color scheme
- **Configuration**: TypeScript, Tailwind, and build setup complete

## Development Guidelines
- Follow modern React patterns with TypeScript
- Use TanStack Query for all API interactions
- Maintain consistent luxury design aesthetic
- Prioritize Telegram Web App optimization
- Implement proper error handling and loading states

## Next Steps
1. Start the development server
2. Test all game functionalities
3. Verify @send bot integration
4. Deploy to production